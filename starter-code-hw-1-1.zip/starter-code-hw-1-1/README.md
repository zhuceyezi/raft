# CS 350 Starter Code Pack

## Project 1 : MapReduce

### Due Date: Feb 17th (at midnight)

Please navigate to `mr` directory for detailed instructions regarding MapReduce assignment.

## Project 2 : Raft

Coming soon
